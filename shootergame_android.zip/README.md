Advanced 2D Shooting Game (Android)
==================================
This is a minimal Android Studio project (Kotlin) implementing a 2D shooting game using SurfaceView.

Features:
- Player ship controlled by touch (drag) and tap-to-shoot
- Enemies spawn in waves with increasing difficulty
- Bullets, collisions, score, levels, health
- Simple power-up system and multiple enemy types
- All graphics drawn with Canvas (no bitmap assets required)

How to build:
1. Download and unzip the project.
2. Open the folder in Android Studio (File > Open).
3. Let Gradle sync and build. (Requires Android SDK and a JDK)
4. Run on an emulator or device (minSdkVersion 21).

Notes:
- This is a starting advanced template: you can extend it with images, sounds, touch controls, multiplayer, ads, etc.
- To produce a signed APK, follow Android Studio's Build > Generate Signed Bundle / APK.
