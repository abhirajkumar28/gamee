package com.example.shootergame

class Player {
    var x = 0f
    var y = 0f
    var width = 100f
    var height = 100f
    var speed = 8f
    var hp = 5
    var fireRate = 300L
    var lastShot = 0L
}

class Bullet(var x: Float, var y: Float, var vy: Float) {
    var damage = 1
}

class Enemy {
    var x = 0f
    var y = 0f
    var vx = 0f
    var vy = 2f
    var size = 60f
    var hp = 1
    var type = 0
    var points = 5
}

class PowerUp {
    var x = 0f
    var y = 0f
    var vy = 2f
    var kind = 0
}
