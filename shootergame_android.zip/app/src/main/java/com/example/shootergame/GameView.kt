package com.example.shootergame

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.hypot
import kotlin.random.Random

class GameView(context: Context) : SurfaceView(context), Runnable, SurfaceHolder.Callback {
    private val threadLock = Object()
    private var running = false
    private var gameThread: Thread? = null
    private val holderRef = holder

    // Screen
    private var screenW = 1080
    private var screenH = 1920

    // Game objects
    private val player = Player()
    private val bullets = mutableListOf<Bullet>()
    private val enemies = mutableListOf<Enemy>()
    private val powerUps = mutableListOf<PowerUp>()

    // Paints
    private val paint = Paint().apply { isAntiAlias = true }
    private val textPaint = Paint().apply { textSize = 60f; isAntiAlias = true }

    // Game state
    private var score = 0
    private var level = 1
    private var spawnTimer = 0L
    private var lastSpawn = System.currentTimeMillis()
    private var lastFrame = System.currentTimeMillis()
    private var touchX = -1f
    private var touchY = -1f
    private var isShooting = false

    init {
        holderRef.addCallback(this)
        // initialize player
        player.width = 120f
        player.height = 120f
        player.x = (screenW / 2).toFloat()
        player.y = (screenH - 300).toFloat()
        player.speed = 10f
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        screenW = width
        screenH = height
        player.x = (screenW / 2).toFloat()
        player.y = (screenH - 300).toFloat()
        start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) { stop() }

    fun start() {
        synchronized(threadLock) {
            running = true
            gameThread = Thread(this)
            gameThread?.start()
        }
    }
    fun stop() {
        synchronized(threadLock) {
            running = false
            try {
                gameThread?.join()
            } catch (e: InterruptedException) { }
        }
    }

    override fun run() {
        while (running) {
            val now = System.currentTimeMillis()
            val delta = now - lastFrame
            if (delta < 16) {
                Thread.sleep(4)
                continue
            }
            update(delta)
            val canvas = if (holderRef.surface.isValid) holderRef.lockCanvas() else null
            canvas?.let {
                drawGame(it)
                holderRef.unlockCanvasAndPost(it)
            }
            lastFrame = now
        }
    }

    private fun update(deltaMs: Long) {
        // spawn logic
        val now = System.currentTimeMillis()
        if (now - lastSpawn > (1500L - (level * 50).coerceAtMost(1000))) {
            spawnEnemy()
            lastSpawn = now
        }

        // move player toward touch if dragging
        if (touchX >= 0 && touchY >= 0) {
            val dx = touchX - player.x
            val dy = touchY - player.y
            val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (dist > 5f) {
                val nx = dx / dist
                val ny = dy / dist
                player.x += nx * player.speed
                player.y += ny * player.speed
            }
        }

        // shooting
        if (isShooting && System.currentTimeMillis() - player.lastShot > player.fireRate) {
            bullets.add(Bullet(player.x, player.y - player.height / 2, -20f))
            player.lastShot = System.currentTimeMillis()
        }

        // update bullets
        val bulletsToRemove = mutableListOf<Bullet>()
        for (b in bullets) {
            b.y += b.vy
            if (b.y < -50 || b.y > screenH + 50) bulletsToRemove.add(b)
        }
        bullets.removeAll(bulletsToRemove)

        // update enemies
        val enemiesToRemove = mutableListOf<Enemy>()
        for (e in enemies) {
            e.y += e.vy
            e.x += e.vx
            // bounce horizontally
            if (e.x < 0 || e.x > screenW) e.vx = -e.vx
            if (e.y > screenH + 200) enemiesToRemove.add(e)
            // collide with bullets
            for (b in bullets) {
                if (RectF(e.x - e.size/2, e.y - e.size/2, e.x + e.size/2, e.y + e.size/2)
                        .intersect(RectF(b.x-8, b.y-16, b.x+8, b.y+16))) {
                    e.hp -= b.damage
                    bulletsToRemove.add(b)
                    if (e.hp <= 0) {
                        score += e.points
                        enemiesToRemove.add(e)
                        // small chance powerup
                        if (Random.nextFloat() < 0.15f) spawnPowerUp(e.x, e.y)
                    }
                    break
                }
            }
            // collide with player
            if (RectF(e.x - e.size/2, e.y - e.size/2, e.x + e.size/2, e.y + e.size/2)
                    .intersect(RectF(player.x - player.width/2, player.y - player.height/2, player.x + player.width/2, player.y + player.height/2))) {
                enemiesToRemove.add(e)
                player.hp -= 1
                if (player.hp <= 0) {
                    // reset
                    level = 1
                    score = 0
                    player.hp = 5
                    enemies.clear()
                    bullets.clear()
                    powerUps.clear()
                }
            }
        }
        enemies.removeAll(enemiesToRemove)
        bullets.removeAll(bulletsToRemove)

        // update powerups
        val puRemove = mutableListOf<PowerUp>()
        for (p in powerUps) {
            p.y += p.vy
            if (RectF(p.x-20, p.y-20, p.x+20, p.y+20)
                    .intersect(RectF(player.x - player.width/2, player.y - player.height/2, player.x + player.width/2, player.y + player.height/2))) {
                applyPowerUp(p)
                puRemove.add(p)
            }
            if (p.y > screenH + 50) puRemove.add(p)
        }
        powerUps.removeAll(puRemove)

        // level up based on score
        level = 1 + (score / 50)
    }

    private fun drawGame(canvas: Canvas) {
        // background
        canvas.drawRGB(10, 10, 30)
        // draw player
        paint.setARGB(255, 100, 200, 255)
        canvas.drawRoundRect(player.x - player.width/2, player.y - player.height/2,
                player.x + player.width/2, player.y + player.height/2, 20f, 20f, paint)
        // draw bullets
        paint.setARGB(255, 255, 255, 120)
        for (b in bullets) {
            canvas.drawRect(b.x-8, b.y-16, b.x+8, b.y+16, paint)
        }
        // draw enemies
        for (e in enemies) {
            when (e.type) {
                0 -> paint.setARGB(255, 220, 50, 50)
                1 -> paint.setARGB(255, 220, 120, 40)
                else -> paint.setARGB(255, 180, 80, 200)
            }
            canvas.drawCircle(e.x, e.y, e.size/2, paint)
        }
        // draw powerups
        for (p in powerUps) {
            paint.setARGB(255, 120, 255, 120)
            canvas.drawRect(p.x-20, p.y-20, p.x+20, p.y+20, paint)
        }
        // HUD
        textPaint.setARGB(255, 255, 255, 255)
        canvas.drawText("Score: $score", 40f, 80f, textPaint)
        canvas.drawText("Level: $level", 40f, 150f, textPaint)
        canvas.drawText("HP: ${player.hp}", 40f, 220f, textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                touchX = event.x
                touchY = event.y
                // if tap near top, shoot; if drag, move
                if (event.y < screenH * 0.6f) {
                    isShooting = true
                } else {
                    isShooting = false
                }
            }
            MotionEvent.ACTION_MOVE -> {
                touchX = event.x
                touchY = event.y
                isShooting = false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                touchX = -1f
                touchY = -1f
                isShooting = false
            }
        }
        return true
    }

    fun pause() { stop() }
    fun resume() { start() }

    private fun spawnEnemy() {
        val t = Random.nextInt(0, 3) // type
        val size = when (t) {
            0 -> Random.nextInt(60, 120).toFloat()
            1 -> Random.nextInt(40, 80).toFloat()
            else -> Random.nextInt(30, 60).toFloat()
        }
        val e = Enemy()
        e.type = t
        e.x = Random.nextInt(50, screenW - 50).toFloat()
        e.y = -50f
        e.size = size
        e.vy = (2f + level * 0.2f) + Random.nextFloat() * 3f
        e.vx = (Random.nextFloat() - 0.5f) * 6f
        e.hp = when (t) {
            0 -> 3 + level/5
            1 -> 2 + level/7
            else -> 1 + level/10
        }
        e.points = when (t) {
            0 -> 10
            1 -> 6
            else -> 3
        }
        enemies.add(e)
    }

    private fun spawnPowerUp(x: Float, y: Float) {
        val p = PowerUp()
        p.x = x
        p.y = y
        p.vy = 3f
        p.kind = Random.nextInt(0, 3)
        powerUps.add(p)
    }

    private fun applyPowerUp(p: PowerUp) {
        when (p.kind) {
            0 -> { player.hp = (player.hp + 2).coerceAtMost(10) } // heal
            1 -> { player.fireRate = (player.fireRate - 80).coerceAtLeast(80) } // faster fire
            2 -> { player.speed += 2f } // speed boost
        }
    }
}
